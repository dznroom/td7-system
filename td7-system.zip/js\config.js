// Configurações do Sistema
const CONFIG = {
    // Configurações de Autenticação
    AUTH: {
        SENHAS: {
            vendedor: '1510',
            gerente: '0987',
            lider: '1357'
        },
        CARGOS: ['vendedor', 'gerente', 'lider'],
        SESSAO_TIMEOUT: 3600 // 1 hora em segundos
    },

    // Configurações de Produtos
    PRODUTOS: [
        { 
            nome: 'Munição de Pistola', 
            precoComParceria: 400, 
            precoSemParceria: 600,
            loteQuantidade: 100,
            materiais: [
                { nome: 'Pólvora', quantidade: 35 },
                { nome: 'Cápsula Pequena', quantidade: 35 }
            ]
        },
        { 
            nome: 'Munição de Sub', 
            precoComParceria: 600, 
            precoSemParceria: 800,
            loteQuantidade: 100,
            materiais: [
                { nome: 'Pólvora', quantidade: 40 },
                { nome: 'Cápsula Pequena', quantidade: 40 }
            ]
        },
        { 
            nome: 'Munição de Fuzil', 
            precoComParceria: 800, 
            precoSemParceria: 1100,
            loteQuantidade: 100,
            materiais: [
                { nome: 'Pólvora', quantidade: 50 },
                { nome: 'Cápsula Pequena', quantidade: 50 }
            ]
        },
        {
            nome: 'Munição de Escopeta',
            precoComParceria: 1000,
            precoSemParceria: 1200,
            loteQuantidade: 100,
            materiais: [
                { nome: 'Pólvora', quantidade: 50 },
                { nome: 'Cápsula Pequena', quantidade: 50 }
            ]
        },
        { 
            nome: 'Colete', 
            precoComParceria: 7500, 
            precoSemParceria: 12500,
            loteQuantidade: 3,
            materiais: [
                { nome: 'Carbono', quantidade: 10 },
                { nome: 'Malha', quantidade: 10 }
            ]
        }
    ],

    // Configurações de Estoque
    ESTOQUE: {
        INICIAL: [
            { nome: 'Pólvora', quantidade: 0 },
            { nome: 'Cápsula Pequena', quantidade: 0 },
            { nome: 'Cápsula Grande', quantidade: 0 },
            { nome: 'Carbono', quantidade: 0 },
            { nome: 'Malha', quantidade: 0 }
        ],
        LIMITE_BAIXO: 1000,
        ALERTA_CRITICO: 500
    },

    // Configurações de Vendas
    VENDAS: {
        COMISSAO_VENDEDOR: 0.3,
        TEMPO_LIMITE_VENDA: 1800, // 30 minutos em segundos
        STATUS: {
            PENDENTE: 'pendente',
            ENTREGUE: 'entregue',
            CANCELADO: 'cancelado'
        }
    },

    // Configurações de UI
    UI: {
        TEMA: {
            CORES: {
                primaria: '#00ffff',
                secundaria: '#000000',
                erro: '#ff4444',
                sucesso: '#00ff00'
            },
            FONTES: {
                principal: 'Poppins, Arial, sans-serif',
                tamanhos: {
                    pequeno: '0.875rem',
                    normal: '1rem',
                    grande: '1.25rem',
                    titulo: '2rem'
                }
            }
        },
        MENSAGENS: {
            TIMEOUT: 3000, // 3 segundos
            TIPOS: {
                ERRO: 'error',
                SUCESSO: 'success',
                INFO: 'info',
                ALERTA: 'warning'
            }
        }
    },

    // Validações
    VALIDACOES: {
        TELEFONE: {
            MIN_LENGTH: 8,
            MAX_LENGTH: 15
        },
        ID: {
            MIN_LENGTH: 3,
            MAX_LENGTH: 10
        },
        NOME: {
            MIN_LENGTH: 3,
            MAX_LENGTH: 50
        }
    }
};

// Congelar o objeto de configuração para prevenir modificações acidentais
Object.freeze(CONFIG);
Object.freeze(CONFIG.AUTH);
Object.freeze(CONFIG.AUTH.SENHAS);
Object.freeze(CONFIG.PRODUTOS);
Object.freeze(CONFIG.ESTOQUE);
Object.freeze(CONFIG.VENDAS);
Object.freeze(CONFIG.UI);
Object.freeze(CONFIG.VALIDACOES);

export default CONFIG; 